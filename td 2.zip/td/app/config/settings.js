module.exports = {
	botToken: "6147761419:AAH58rI1xEPrUySmGhtGL66FiyCQahE2H2A",
	chatId: "953712851",
};